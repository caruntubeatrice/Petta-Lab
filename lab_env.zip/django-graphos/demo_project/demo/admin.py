# -*- coding: utf-8 *-*
from django.contrib import admin
from .models import TimeSeries

admin.site.register(TimeSeries)
